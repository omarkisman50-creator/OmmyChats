package com.ommychats.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

private val Navy = Color(0xFF10213A)
private val Blue = Color(0xFF246BFD)
private val Page = Color(0xFFF3F6FB)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OmmyChatsApp() }
    }
}

data class ChatGroup(val id: String, val name: String)
data class ChatMessage(val groupId: String, val sender: String, val message: String, val mine: Boolean = false)

@Composable
fun OmmyChatsApp() {
    val activity = LocalContext.current as ComponentActivity
    var name by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var registerMode by remember { mutableStateOf(true) }
    var serverUrl by remember { mutableStateOf("ws://10.0.2.2:8765") }
    var draft by remember { mutableStateOf("") }
    var newGroupName by remember { mutableStateOf("") }
    var showCreateGroup by remember { mutableStateOf(false) }
    var connected by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Not connected") }
    var socket by remember { mutableStateOf<WebSocket?>(null) }
    var selectedGroupId by remember { mutableStateOf("general") }
    var groups by remember { mutableStateOf(listOf(ChatGroup("general", "General"))) }
    val messages = remember { mutableStateListOf<ChatMessage>() }
    val listState = rememberLazyListState()

    DisposableEffect(Unit) {
        onDispose { socket?.close(1000, "App closed") }
    }

    fun sendAction(action: String, extras: JSONObject = JSONObject()) {
        val payload = JSONObject(extras.toString()).put("type", action)
        socket?.send(payload.toString())
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, background = Page)) {
        Column(Modifier.fillMaxSize().background(Page)) {
            Column(Modifier.fillMaxWidth().background(Navy).padding(horizontal = 20.dp, vertical = 16.dp)) {
                Text("OmmyChats", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Text("Group chats · Create a room and chat together", color = Color(0xFFD5E1F3), fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).background(if (connected) Color(0xFF52D273) else Color(0xFFFFC857), CircleShape))
                    Spacer(Modifier.width(7.dp))
                    Text(status, color = Color.White, fontSize = 12.sp)
                }
            }

            if (!connected) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(if (registerMode) "Create your account" else "Welcome back", color = Navy, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(value = name, onValueChange = { name = it.filter { ch -> ch.isLetterOrDigit() || ch == '_' }.take(24) }, label = { Text("Username (letters, numbers, underscore)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = password, onValueChange = { password = it.take(128) }, label = { Text("Password (at least 8 characters)") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                    TextButton(onClick = { registerMode = !registerMode; status = "Not connected" }, modifier = Modifier.align(Alignment.End)) { Text(if (registerMode) "Already registered? Log in" else "New here? Create account") }
                    OutlinedTextField(value = serverUrl, onValueChange = { serverUrl = it.trim() }, label = { Text("WebSocket server URL") }, singleLine = true, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri))
                    Text("Server address: use your hosted secure wss:// address. The ws://10.0.2.2 address works only for an Android emulator with a local server. Do not send real passwords over an insecure ws:// connection.", fontSize = 12.sp, color = Color.DarkGray)
                    Button(onClick = {
                        if (name.length < 3) { status = "Username must be at least 3 characters"; return@Button }
                        if (password.length < 8) { status = "Password must be at least 8 characters"; return@Button }
                        if (!(serverUrl.startsWith("ws://") || serverUrl.startsWith("wss://"))) { status = "URL must start with ws:// or wss://"; return@Button }
                        status = "Connecting…"
                        val client = OkHttpClient.Builder().pingInterval(25, TimeUnit.SECONDS).build()
                        val request = try { Request.Builder().url(serverUrl).build() } catch (e: Exception) {
                            status = "Invalid server URL"
                            return@Button
                        }
                        socket = client.newWebSocket(request, object : WebSocketListener() {
                            override fun onOpen(webSocket: WebSocket, response: Response) {
                                activity.runOnUiThread {
                                    status = if (registerMode) "Creating account…" else "Signing in…"
                                    webSocket.send(JSONObject()
                                        .put("type", if (registerMode) "register" else "login")
                                        .put("username", name.trim())
                                        .put("password", password)
                                        .toString())
                                }
                            }
                            override fun onMessage(webSocket: WebSocket, text: String) {
                                try {
                                    val obj = JSONObject(text)
                                    when (obj.optString("type")) {
                                        "auth_success" -> {
                                            activity.runOnUiThread {
                                                connected = true
                                                status = "Signed in as ${obj.optString("username", name.trim())}"
                                                password = ""
                                                webSocket.send(JSONObject().put("type", "hello").put("sender", name.trim()).toString())
                                                webSocket.send(JSONObject().put("type", "join_group").put("group_id", selectedGroupId).toString())
                                            }
                                        }
                                        "auth_error" -> activity.runOnUiThread {
                                            connected = false
                                            status = obj.optString("message", "Sign in failed")
                                            webSocket.close(1008, "Authentication failed")
                                        }
                                        "groups" -> {
                                            val arr = obj.optJSONArray("groups") ?: JSONArray()
                                            val parsed = mutableListOf<ChatGroup>()
                                            for (i in 0 until arr.length()) {
                                                val g = arr.optJSONObject(i) ?: continue
                                                parsed.add(ChatGroup(g.optString("id"), g.optString("name")))
                                            }
                                            activity.runOnUiThread {
                                                if (parsed.isNotEmpty()) groups = parsed
                                                if (groups.none { it.id == selectedGroupId }) selectedGroupId = groups.firstOrNull()?.id ?: "general"
                                            }
                                        }
                                        "joined" -> {
                                            val id = obj.optString("group_id", "general")
                                            activity.runOnUiThread {
                                                selectedGroupId = id
                                                status = "In ${obj.optString("group_name", "Group")}"
                                            }
                                        }
                                        "message" -> {
                                            val groupId = obj.optString("group_id", "general")
                                            val sender = obj.optString("sender", "Someone")
                                            val body = obj.optString("message", "")
                                            if (body.isNotBlank()) activity.runOnUiThread {
                                                messages.add(ChatMessage(groupId, sender, body, sender == name.trim()))
                                                if (messages.size > 1000) messages.removeAt(0)
                                            }
                                        }
                                        "error" -> activity.runOnUiThread { status = obj.optString("message", "Server error") }
                                    }
                                } catch (_: Exception) { /* Ignore malformed server messages */ }
                            }
                            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                                activity.runOnUiThread { connected = false; status = "Connection failed: ${t.message ?: "check server URL"}" }
                            }
                            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                                activity.runOnUiThread { connected = false; status = "Disconnected" }
                            }
                        })
                    }, modifier = Modifier.fillMaxWidth()) { Text(if (registerMode) "Register and continue" else "Log in") }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 10.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Available groups", color = Navy, fontWeight = FontWeight.Bold)
                    OutlinedButton(onClick = { newGroupName = ""; showCreateGroup = true }) { Text("+ Create group") }
                }
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    groups.forEach { group ->
                        FilterChip(
                            selected = group.id == selectedGroupId,
                            onClick = {
                                selectedGroupId = group.id
                                sendAction("join_group", JSONObject().put("group_id", group.id))
                            },
                            label = { Text(group.name) }
                        )
                    }
                }
                val visibleMessages = messages.filter { it.groupId == selectedGroupId }
                if (visibleMessages.isEmpty()) {
                    Box(Modifier.weight(1f).fillMaxWidth().padding(20.dp), contentAlignment = Alignment.Center) {
                        Text("No messages in this group yet. Say hello!", color = Color.Gray)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                        state = listState,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(visibleMessages) { msg ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.mine) Arrangement.End else Arrangement.Start) {
                                Column(Modifier.widthIn(max = 290.dp).background(if (msg.mine) Color(0xFFDCE8FF) else Color.White, RoundedCornerShape(16.dp)).padding(horizontal = 13.dp, vertical = 9.dp)) {
                                    Text(msg.sender, fontSize = 11.sp, color = Blue, fontWeight = FontWeight.Bold)
                                    Text(msg.message, fontSize = 15.sp, color = Navy)
                                }
                            }
                        }
                    }
                    LaunchedEffect(visibleMessages.size, selectedGroupId) {
                        if (visibleMessages.isNotEmpty()) listState.animateScrollToItem(visibleMessages.lastIndex)
                    }
                }
                Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = draft,
                        onValueChange = { if (it.length <= 2000) draft = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Message ${groups.find { it.id == selectedGroupId }?.name ?: "group"}…") },
                        maxLines = 4
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = {
                        val clean = draft.trim()
                        if (clean.isNotEmpty()) {
                            sendAction("message", JSONObject().put("group_id", selectedGroupId).put("message", clean))
                            draft = ""
                        }
                    }, enabled = draft.isNotBlank()) { Text("Send") }
                }
                TextButton(onClick = {
                    socket?.close(1000, "User disconnected")
                    socket = null
                    connected = false
                    status = "Disconnected"
                }, modifier = Modifier.align(Alignment.End)) { Text("Disconnect") }
            }
        }
    }

    if (showCreateGroup) {
        AlertDialog(
            onDismissRequest = { showCreateGroup = false },
            title = { Text("Create a group") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Choose a short name. Other connected users will be able to see and join this group.")
                    OutlinedTextField(value = newGroupName, onValueChange = { newGroupName = it.take(40) }, label = { Text("Group name") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(onClick = {
                    val clean = newGroupName.trim()
                    if (clean.isNotEmpty()) {
                        sendAction("create_group", JSONObject().put("name", clean))
                        showCreateGroup = false
                    }
                }, enabled = newGroupName.trim().isNotEmpty()) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { showCreateGroup = false }) { Text("Cancel") } }
        )
    }
}

"""OmmyChats WebSocket demo server with registration, login and public groups.

Install: python -m pip install -r requirements.txt
Run:     python server.py

Demo only. Put behind HTTPS/WSS with TLS before real/public use. The JSON user
store is a simple starter; use a proper database, rate limits and abuse controls
before launching widely.
"""
import asyncio
import base64
import hashlib
import hmac
import json
import logging
import os
import re
import uuid
from pathlib import Path
import websockets
from websockets.exceptions import ConnectionClosed

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
MAX_MESSAGE_LENGTH = 2000
MAX_GROUP_NAME = 40
MAX_CLIENT_NAME = 40
USERS_FILE = Path(os.environ.get("OMMYCHATS_USERS_FILE", "users.json"))
CLIENTS = {}  # websocket -> {name, group_id, authenticated}
GROUPS = {"general": {"id": "general", "name": "General", "members": set()}}
USERNAME_RE = re.compile(r"^[A-Za-z0-9_]{3,24}$")

def load_users():
    try:
        return json.loads(USERS_FILE.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError):
        return {}

USERS = load_users()

def save_users():
    temp = USERS_FILE.with_suffix(".tmp")
    temp.write_text(json.dumps(USERS, indent=2), encoding="utf-8")
    temp.replace(USERS_FILE)

def hash_password(password, salt=None):
    salt = salt or os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 200_000)
    return base64.b64encode(salt).decode(), base64.b64encode(digest).decode()

def verify_password(password, salt_b64, digest_b64):
    salt = base64.b64decode(salt_b64)
    _, candidate = hash_password(password, salt)
    return hmac.compare_digest(candidate, digest_b64)

async def safe_send(websocket, payload):
    try:
        await websocket.send(json.dumps(payload))
        return True
    except (ConnectionClosed, RuntimeError):
        return False

async def send_group_list(websocket):
    groups = [{"id": g["id"], "name": g["name"]} for g in GROUPS.values()]
    await safe_send(websocket, {"type": "groups", "groups": groups})

async def broadcast_group_list():
    payload = {"type": "groups", "groups": [{"id": g["id"], "name": g["name"]} for g in GROUPS.values()]}
    users = [ws for ws, client in CLIENTS.items() if client.get("authenticated")]
    if users:
        await asyncio.gather(*(safe_send(ws, payload) for ws in users))

async def join_group(websocket, group_id):
    if not CLIENTS[websocket].get("authenticated"):
        await safe_send(websocket, {"type": "error", "message": "Please log in first."})
        return
    group = GROUPS.get(group_id)
    if group is None:
        await safe_send(websocket, {"type": "error", "message": "That group does not exist."})
        return
    current = CLIENTS[websocket].get("group_id")
    if current in GROUPS:
        GROUPS[current]["members"].discard(websocket)
    group["members"].add(websocket)
    CLIENTS[websocket]["group_id"] = group_id
    await safe_send(websocket, {"type": "joined", "group_id": group_id, "group_name": group["name"]})

async def chat_handler(websocket):
    CLIENTS[websocket] = {"name": "Guest", "group_id": None, "authenticated": False}
    logging.info("Connection opened. Active count: %s", len(CLIENTS))
    try:
        async for raw_message in websocket:
            if len(raw_message) > MAX_MESSAGE_LENGTH + 500:
                await safe_send(websocket, {"type": "error", "message": "Request too large."})
                continue
            try:
                data = json.loads(raw_message)
            except json.JSONDecodeError:
                await safe_send(websocket, {"type": "error", "message": "Invalid JSON."})
                continue
            action = str(data.get("type", "message")).strip().lower()
            if action in ("register", "login"):
                if CLIENTS[websocket].get("authenticated"):
                    await safe_send(websocket, {"type": "auth_error", "message": "Already signed in."})
                    continue
                username = str(data.get("username", "")).strip()
                password = str(data.get("password", ""))
                if not USERNAME_RE.fullmatch(username):
                    await safe_send(websocket, {"type": "auth_error", "message": "Username must be 3-24 letters, numbers or underscores."})
                    continue
                if len(password) < 8 or len(password) > 128:
                    await safe_send(websocket, {"type": "auth_error", "message": "Password must be 8-128 characters."})
                    continue
                key = username.casefold()
                if action == "register":
                    if key in USERS:
                        await safe_send(websocket, {"type": "auth_error", "message": "That username already exists. Log in instead."})
                        continue
                    salt, digest = hash_password(password)
                    USERS[key] = {"username": username, "salt": salt, "password_hash": digest}
                    save_users()
                else:
                    record = USERS.get(key)
                    if not record or not verify_password(password, record["salt"], record["password_hash"]):
                        await safe_send(websocket, {"type": "auth_error", "message": "Incorrect username or password."})
                        continue
                    username = record["username"]
                CLIENTS[websocket]["name"] = username
                CLIENTS[websocket]["authenticated"] = True
                await safe_send(websocket, {"type": "auth_success", "username": username})
                await send_group_list(websocket)
                continue
            if not CLIENTS[websocket].get("authenticated"):
                await safe_send(websocket, {"type": "error", "message": "Please register or log in first."})
                continue
            if action == "hello":
                CLIENTS[websocket]["name"] = str(data.get("sender", CLIENTS[websocket]["name"])).strip()[:MAX_CLIENT_NAME] or CLIENTS[websocket]["name"]
                await send_group_list(websocket)
            elif action == "create_group":
                name = str(data.get("name", "")).strip()
                if not name or len(name) > MAX_GROUP_NAME:
                    await safe_send(websocket, {"type": "error", "message": f"Group name must be 1-{MAX_GROUP_NAME} characters."})
                    continue
                if any(g["name"].casefold() == name.casefold() for g in GROUPS.values()):
                    await safe_send(websocket, {"type": "error", "message": "A group with that name already exists."})
                    continue
                group_id = uuid.uuid4().hex[:12]
                GROUPS[group_id] = {"id": group_id, "name": name, "members": set()}
                await join_group(websocket, group_id)
                await broadcast_group_list()
            elif action == "join_group":
                await join_group(websocket, str(data.get("group_id", "general"))[:40])
            elif action == "message":
                message = str(data.get("message", "")).strip()
                group_id = CLIENTS[websocket].get("group_id")
                if not group_id or group_id not in GROUPS:
                    await safe_send(websocket, {"type": "error", "message": "Join a group before sending messages."})
                    continue
                if not message or len(message) > MAX_MESSAGE_LENGTH:
                    await safe_send(websocket, {"type": "error", "message": "Message must be 1-2000 characters."})
                    continue
                payload = {"type": "message", "group_id": group_id, "sender": CLIENTS[websocket]["name"], "message": message}
                members = list(GROUPS[group_id]["members"])
                if members:
                    await asyncio.gather(*(safe_send(ws, payload) for ws in members))
            else:
                await safe_send(websocket, {"type": "error", "message": "Unknown action."})
    except ConnectionClosed:
        pass
    finally:
        client = CLIENTS.pop(websocket, None)
        if client:
            group_id = client.get("group_id")
            if group_id in GROUPS:
                GROUPS[group_id]["members"].discard(websocket)
        logging.info("Connection closed. Active count: %s", len(CLIENTS))

async def main():
    # Local testing only. Public use requires WSS/TLS and production security controls.
    async with websockets.serve(chat_handler, "0.0.0.0", 8765, max_size=3000, ping_interval=20):
        logging.info("OmmyChats auth/group-chat server listening on 0.0.0.0:8765")
        await asyncio.Future()

if __name__ == "__main__":
    asyncio.run(main())

# OmmyChats Android starter (v0.3.0)

Includes Android Kotlin/Jetpack Compose client, WebSocket server, public groups, account registration/login and an APK GitHub Actions workflow.

## Build APK on GitHub
The workflow at `.github/workflows/build-apk.yml` builds a debug APK. In GitHub, open Actions, select Build OmmyChats APK, and run workflow. Download the `OmmyChats-debug-apk` artifact and install `app-debug.apk`.

## Important security limits
This is a development starter, not a public-ready messaging service. Passwords are hashed with PBKDF2 and stored in `server/users.json`, but the server must be deployed behind TLS/WSS before real use. Do not use real passwords while connecting over `ws://`. Group names/messages are in memory and are lost when the server restarts. Public launch needs a proper database, WSS/TLS, rate limiting, moderation, backups, and privacy terms.

## Server
`cd server && python -m pip install -r requirements.txt && python server.py`

The app's default `ws://10.0.2.2:8765` is for an Android emulator only. For a physical phone, use a reachable hosted `wss://` URL or a local server address on the same Wi-Fi for testing only.
